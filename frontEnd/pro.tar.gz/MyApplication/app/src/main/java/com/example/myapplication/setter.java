package com.example.myapplication;

public class setter {

    private static String ptid;


    public static String getPtid() {
        return ptid;
    }

    public void setPtid(String ptid) {
        this.ptid = ptid;
    }
}
