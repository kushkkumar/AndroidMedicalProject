package com.example.myapplication;

import com.google.gson.annotations.SerializedName;

public class storeresultpermanent {
    @SerializedName("ppid")
    private String ppid;

    public String getPpid() {
        return ppid;
    }
}
